package football.entities.field;

public class ArtificialTurf extends BaseField{
    public ArtificialTurf(String name){
        super(name, 150);
    }
}
