package restaurant.entities.healthyFoods.interfaces;

public class VeganBiscuits extends Food{
    public VeganBiscuits(String name, double price) {
        super(name, 205, price);
    }
}
