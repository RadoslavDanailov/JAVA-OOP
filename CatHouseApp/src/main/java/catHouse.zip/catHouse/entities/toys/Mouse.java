package catHouse.entities.toys;

public class Mouse extends BaseToy{
    public Mouse(int softness, double price) {
        super(5, 15);
    }
}
