package catHouse.entities.houses;

import catHouse.common.ConstantMessages;
import catHouse.common.ExceptionMessages;
import catHouse.entities.cat.Cat;
import catHouse.entities.toys.Toy;

import java.util.ArrayList;
import java.util.Collection;

public abstract class BaseHouse implements House{
    private String name;
    private int capacity;
    private Collection<Toy>toys;
    private Collection<Cat>cats;

    public BaseHouse(String name, int capacity) {
        this.setName(name);
        this.setCapacity(capacity);
        this.toys = new ArrayList<>();
        this.cats = new ArrayList<>();
    }

    protected int getCapacity() {
        return this.capacity;
    }

    protected void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    protected void setToys(Collection<Toy> toys) {
        this.toys = toys;
    }

    protected void setCats(Collection<Cat> cats) {
        this.cats = cats;
    }

    @Override
    public int sumSoftness() {
        int sum = 0;
        for (Toy toy : this.getToys()){
            sum += toy.getSoftness();
        }
        return sum;
    }

    @Override
    public void addCat(Cat cat) {
        if (this.getCapacity() > this.cats.size()){
            this.cats.add(cat);
        }
        else {
            throw new IllegalStateException(ConstantMessages.NOT_ENOUGH_CAPACITY_FOR_CAT);
        }
    }

    @Override
    public void removeCat(Cat cat) {
        this.cats.remove(cat);
    }

    @Override
    public void buyToy(Toy toy) {
        this.toys.add(toy);
    }

    @Override
    public void feeding() {
        for (Cat cat : this.cats){
            cat.eating();
        }
    }

    @Override
    public String getStatistics() {
        StringBuilder builder = new StringBuilder();
        if (this.cats.isEmpty()){
            builder.append("none");
        }
        else {
            builder.append(String.format("%s %s:%n",this.getName(), this.getClass().getSimpleName()));
            builder.append("Cats: ");
            for (Cat cat : this.cats){
                builder.append(cat.getName()).append(" ");
            }
            builder.append("Toys: ").append(this.toys.size()).append(" Softness: ").append(this.sumSoftness());

        }
        return builder.toString().trim();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()){
            throw new NullPointerException(ExceptionMessages.HOUSE_NAME_CANNOT_BE_NULL_OR_EMPTY);
        }
    }

    @Override
    public Collection<Cat> getCats() {
        return this.cats;
    }

    @Override
    public Collection<Toy> getToys() {
        return this.toys;
    }
}
