package spaceStation.core;

import spaceStation.models.astronauts.Astronaut;
import spaceStation.models.astronauts.Biologist;
import spaceStation.models.astronauts.Geodesist;
import spaceStation.models.astronauts.Meteorologist;
import spaceStation.models.mission.Mission;
import spaceStation.models.mission.MissionImpl;
import spaceStation.models.planets.Planet;
import spaceStation.models.planets.PlanetImpl;
import spaceStation.repositories.AstronautRepository;
import spaceStation.repositories.PlanetRepository;
import spaceStation.repositories.Repository;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ControllerImpl implements Controller {
    private AstronautRepository astronautRepository;
    private PlanetRepository planetRepository;


    public ControllerImpl() {
        this.astronautRepository = new AstronautRepository();
        this.planetRepository = new PlanetRepository();
    }

    @Override
    public String addAstronaut(String type, String astronautName) {
        Astronaut astronaut;
        switch (type){
            case "Biologist":
            astronaut = new Biologist(astronautName);
                break;
            case "Geodesist":
                astronaut = new Geodesist(astronautName);
                break;
            case "Meteorologist":
                astronaut = new Meteorologist(astronautName);
                break;
            default:
                throw new IllegalArgumentException("Astronaut type doesn't exists!");
        }
        this.astronautRepository.add(astronaut);

        return String.format("Successfully added %s: %s!",type, astronautName);
    }

    @Override
    public String addPlanet(String planetName, String... items) {
        List<String>itemsList = Arrays.asList(items);
        Planet planet = new PlanetImpl(planetName);
        planet.getItems().addAll(itemsList);
        this.planetRepository.add(planet);
        return String.format("Successfully added Planet: %s!",planetName);
    }

    @Override
    public String retireAstronaut(String astronautName) {
        String message = null;
        boolean isFound = false;
        for (Astronaut astronaut : this.astronautRepository.getModels()){
            if (astronaut.getName().equals(astronautName)){
                this.astronautRepository.remove(astronaut);
                message = String.format("Astronaut %s was retired!",astronautName);    // findByName
                isFound = true;
                break;
            }
        }
        if (!isFound){
            message = String.format("Astronaut %s doesn't exists!", astronautName);
        }
        return message;
    }

    @Override
    public String explorePlanet(String planetName) {
        List<Astronaut>goodToGo = new ArrayList<>();
        for (Astronaut astronaut : this.astronautRepository.getModels()){
            if (astronaut.getOxygen() >= 60){
                goodToGo.add(astronaut);
            }
        }
        if (goodToGo.size() == 0){
            throw new IllegalArgumentException("You need at least one astronaut to explore the planet!");
        }
        int countBeforeMission = goodToGo.size();
        Mission mission = new MissionImpl();
        Planet planet = this.planetRepository.findByName(planetName);
        mission.explore(planet, goodToGo);
        int countAfterMission = goodToGo.size();

        return String.format("Planet: %s was explored! Exploration finished with %d dead astronauts!"
                                       ,planetName, countBeforeMission - countAfterMission);
    }

    @Override
    public String report() {
        StringBuilder builder = new StringBuilder();

        builder.append(String.format("%d planets were explored!%n", this.planetRepository.getModels().size()));
        builder.append("Astronauts info:\n");
        for (Astronaut astronaut : this.astronautRepository.getModels()){
            builder.append(String.format("Name: %s%n",astronaut.getName()));
            builder.append(String.format("Oxygen: %.0f%n",astronaut.getOxygen()));
            if (astronaut.getBag().getItems().isEmpty()){
                builder.append(String.format("Bag items: none%n"));
            }
            else {
                Collection<String> itemsList = astronaut.getBag().getItems();
                builder.append(String.format("Bag items: %s%n", String.join(", ", itemsList)));
            }
        }



        return builder.toString();
    }
}
