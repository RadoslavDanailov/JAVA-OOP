package zoo.entities.foods;

public class Meat extends BaseFood{

    public Meat(){
        super(70, 10);
    }
}
